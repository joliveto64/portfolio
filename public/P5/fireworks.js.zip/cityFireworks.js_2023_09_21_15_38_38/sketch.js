var fireworks = [];
var cities = [];
var stars = [];
var clouds = [];
const cWidth = 500;
const cHeight = 500;

function setup() {
  createCanvas(500, 500);
  fireworks.push(new Firework(cWidth/2, cHeight));
  
  for (var i=0; i<45; i++){
    cities[i]=new City(cWidth, cHeight);
  }
  for (var c=0; c<100; c++){
    clouds[c]=new Cloud(cWidth, cHeight);
  }
  for (var s = 0; s<75; s++){
    stars[s]=new Star(); 
  } 
}

function draw() {
  background(0,35,55, 200);
  
  for (i=0; i<fireworks.length; i++){
    fireworks[i].launch();
    fireworks[i].explode();
    fireworks[i].smoke();
  }
  
  for (var i=0; i<cities.length; i++){
    cities[i].draw(); 
  }
  
  for (var s = 0; s<stars.length; s++){
    stars[s].draw(); 
  }
  
  for (var c=0; c<clouds.length; c++){
    clouds[c].draw(); 
    clouds[c].move();
  }
}

 function mousePressed(){
  fireworks.push(new Firework(mouseX, cHeight));
   if (fireworks.length>20){
     fireworks.shift();
   }
}