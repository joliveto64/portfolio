class Star{
  constructor(){
  this.ranX=random(0,cWidth);
  this.ranY=random(0,cHeight-425); 
  this.ranS=random(0,3);
  this.shootingX=(0);
  this.shootingY=0;
  this.shootingX+=this.moveX;
  this.shootingY+=this.moveY;
  this.moveX=2;
  this.moveY=1/2;
  }
  
  draw(){ 
  fill(random(130,255), 150);
  noStroke();
  ellipse(this.ranX, this.ranY, this.ranS);
  }
}