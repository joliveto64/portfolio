class Firework{
  constructor(xMouse, y){
    this.x=xMouse;
    this.y=y;
    this.maxHeight=random(y-325,y-175);
    this.speed=random(2,5); 
    this.size=10;
    this.sizeMax=random(100,200);
    this.increaseRate=5;
    this.r=random(100,255);
    this.g=random(100,255);
    this.b=random(100,255);
    this.opacity=1;
    this.smokeSizeX=random(50,125);
    this.smokeSizeY=random(50,125);
    this.smokeSpeed=random(1/10,1/4);
  }
  
  launch(){
    noStroke();
    fill(this.r, this.g, this.b, random(0,255));
    
    if (this.y >= this.maxHeight){
      this.y-=this.speed;
      ellipse(this.x, this.y, 8);
    } 
  }
  
  explode(){
    strokeWeight(30);
    stroke(200, random(0,150));
    fill(this.r, this.g, this.b, random(0,200));
    
    if (this.y<this.maxHeight && this.size<this.sizeMax){
       this.size+=this.increaseRate;
       ellipse(this.x, this.y, this.size);
       background(this.r,this.g,this.b, random(10,40));  
    }
  } 
  
  smoke(){
    noStroke();
    fill(0,3.5);
    
    if (this.y<this.maxHeight){
      ellipse(this.x, this.y, this.smokeSizeX, this.smokeSizeY)     
      ellipse(this.x-20, this.y+20, this.smokeSizeX); 
      ellipse(this.x+30, this.y-30, this.smokeSizeX);
      ellipse(this.x-20, this.y-20, this.smokeSizeX);
      
      this.x+=this.smokeSpeed;
    }
  }
}

