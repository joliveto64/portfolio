class City{
  constructor(x,y){
  this.x=x;
  this.y=y;
  noStroke();
  fill(0);
    this.locX=random(-20,this.x);
    this.locY=random(this.y-120, this.y-10);
    this.sizeX=random(20,40);
    this.sizeY=120;
    this.windowX=random(5,15);
    this.windowY=random(5,50);
    this.window2X=random(5,15);
    this.window2Y=random(5,50);
    this.r=random(150,200);
    this.g=random(125,150);
    this.b=0;
  }
  
  draw(){
    fill(0);
    noStroke();
    rect(this.locX,this.locY,this.sizeX,this.sizeY); 
    
    fill(this.r, this.g,this.b);
    rect(this.locX+this.windowX,this.locY+this.windowY,2,2);
    rect(this.locX+this.window2X,this.locY+this.window2Y,2,2); 
    
    fill(0);
    noStroke();
    rect(0, this.y-20, this.x, 20); 
  }
}