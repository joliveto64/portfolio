function cloud(){
  this.sizeX=random(100,300);
  this.sizeY=random(20,40);
  this.posX=random(0,width);
  this.posY=random(0,height);
  this.posZ=random(0,20);
  this.speed=random(2,1);
  
  this.move=function(){
    this.posX=this.posX+this.speed;
  }
    
  this.show=function(){
    fill(180,50);
    noStroke();
    ellipse(this.posX, this.posY, this.sizeX, this.sizeY);
  }
}
  