var clouds=[];

var r = 0;
var g = 70;
var b = 255;
var white = 255;
var opacity = 3.5;
var counter = 0;

function setup() {
  createCanvas(500, 500);
  
  for (var i = 0; i <1500; i++) {
    clouds[i] = new cloud(); 
  }
}
function draw() {
  print(g, b, counter);
  frameRate(60);
  fill(white,opacity);
  background(r,g,b);

  
  for (var i = 0; i < clouds.length; i++) {
    clouds[i].move();
    clouds[i].show(); 
  }
}

function cloud(){
  this.size=random(10,500);
  this.posX=random(-width/2,width+width*1.5);
  this.posY=random(-200,height+200);
  this.posZ=random(0,20);
  this.speed=random(1/50,1);
  
  this.move=function(){
    this.posX=this.posX+this.speed;   
    
  if (this.posX>width+width/2){
    this.posX=random(-width, -width*1.5);
  }
}
  this.show=function(){
    noStroke();
    ellipse(this.posX, this.posY, this.size);
  }
}




