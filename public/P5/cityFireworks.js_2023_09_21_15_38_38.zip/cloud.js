class Cloud{
  constructor(x,y){
    this.x=x;
    this.y=y;
    this.width=random(100,150);
    this.height=random(20,40);
    this.locationX=random(-150,this.x);
    this.locationY=random(35,100);
    this.speed=random(1/10,1/4);
    this.opacity=1;
  }
  
  draw(){
    noStroke();
    fill(255,this.opacity);
    ellipse(this.locationX,this.locationY,this.width,this.height);
  }
  
  move(){
    this.locationX+=this.speed;
    
    if (this.locationX>this.x+150){
     this.locationX-=this.locationX*1.5;
    }
  }
}