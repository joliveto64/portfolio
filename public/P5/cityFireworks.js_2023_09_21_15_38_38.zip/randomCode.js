//nested loops

for (var x=0; x<=mouseX; x+=25){
     for (var y=0; y<=mouseY; y+=25){
      fill(random(0,100), random(0,100), random(0,100));
      strokeWeight(4);
      stroke(120);
      ellipse(x, y, 20);   
    } 
  } 


//if/else with boolean
if (inc) {
b = b + 1 / 4;
g = g + 1 / 12;
} else {
b = b - 1 / 4;
g = g - 1 / 12;
}

if (b < 41) {
inc = true;
} else if (b > 250) {
inc = false;
}  